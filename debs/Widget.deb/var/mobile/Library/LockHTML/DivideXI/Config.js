/* 
Configurations
Credits: Original code by Dacal & Junesiphone. Modified by Evelyn. Modified v2 by Theadrill.
*/

var Lang = "pt";   // choose between "en", "pt"

